#!/usr/bin/env bash

rm -v ./*_D.dds
rm -v ./*_pre.dds

for line in $(cat files.csv); do
  imgsrc=$(echo $line | cut -d ',' -f 1);
  imgdest=$(echo $line | cut -d ',' -f 2);
  cp -v ~/win/games/ssol-ninjaripper/2023.03.29_13.07.18_A\ Slower\ Speed\ of\ Light.exe_24924/frame_0/$imgsrc.dds ${imgdest}_pre.dds;
  convert ${imgdest}_pre.dds -define dds:compression=DXT5 ${imgdest}_D.dds
  cp gray75.dds ${imgdest}_R.dds
  cp gray.dds ${imgdest}_H.dds
  cp gray.dds ${imgdest}_I.dds
  cp black.dds ${imgdest}_D_HueMask.dds
  cp std-normal.dds ${imgdest}_N.dds
  if [[ $imgdest == *"Lamp"* ]]; then
    cp white.dds ${imgdest}_I.dds
  fi
done

# rm -v ~/win/Documents/Trackmania/ModWork/Image/*.dds
# rm -v ~/win/Documents/Trackmania/Skins/Stadium/ModWork/Image/*.dds
# rm -v ~/win/Documents/Trackmania/Skins/Stadium/ModWork/*.dds

# cp -v -a ./* ~/win/Documents/Trackmania/ModWork/Image/
cp -v -a ./* ~/win/Documents/Trackmania/Skins/Stadium/ModWork/Image/
rm ~/win/Documents/Trackmania/Skins/Stadium/ModWork/Image/*_pre.dds
# cp -v -a ./* ~/win/Documents/Trackmania/Skins/Stadium/ModWork/
